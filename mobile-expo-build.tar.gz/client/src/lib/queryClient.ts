import { QueryClient, QueryFunction } from "@tanstack/react-query";
import { localStorageService } from "./localStorage";
import { type InsertLicense } from "../shared/schema";

// Local API simulation for mutations
export async function apiRequest(
  method: string,
  url: string,
  data?: unknown | undefined,
): Promise<any> {
  const urlParts = url.split('/');
  
  try {
    switch (method) {
      case "POST":
        if (url === "/api/licenses") {
          return await localStorageService.createLicense(data as InsertLicense);
        } else if (url === "/api/licenses/check-duplicate") {
          const { licenseNumber, excludeId } = data as { licenseNumber: string; excludeId?: string };
          const existingLicense = await localStorageService.findLicenseByNumber(licenseNumber, excludeId);
          return { exists: !!existingLicense, license: existingLicense };
        }
        break;
        
      case "PUT":
        if (url.startsWith("/api/licenses/")) {
          const id = urlParts[urlParts.length - 1];
          return await localStorageService.updateLicense(id, data as Partial<InsertLicense>);
        }
        break;
        
      case "DELETE":
        if (url.startsWith("/api/licenses/")) {
          const id = urlParts[urlParts.length - 1];
          const success = await localStorageService.deleteLicense(id);
          if (!success) {
            throw new Error("License not found");
          }
          return { success };
        }
        break;
        
      default:
        throw new Error(`Unsupported method: ${method}`);
    }
  } catch (error) {
    throw new Error(error instanceof Error ? error.message : "Unknown error");
  }
}

// Local query function that uses localStorage instead of API calls
type UnauthorizedBehavior = "returnNull" | "throw";
export const getQueryFn: <T = any>(options: {
  on401: UnauthorizedBehavior;
}) => QueryFunction<T> =
  ({ on401: unauthorizedBehavior }) =>
  async ({ queryKey }) => {
    const url = queryKey.join("/") as string;
    
    try {
      if (url === "/api/licenses") {
        return await localStorageService.getAllLicenses() as T;
      }
      
      if (url.startsWith("/api/licenses/")) {
        const id = url.split('/').pop();
        if (id) {
          return await localStorageService.getLicense(id) as T;
        }
      }
      
      throw new Error(`Unsupported query: ${url}`);
    } catch (error) {
      throw new Error(error instanceof Error ? error.message : "Unknown error");
    }
  };

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      queryFn: getQueryFn({ on401: "throw" }),
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
      retry: false,
    },
    mutations: {
      retry: false,
    },
  },
});

// Setup event listeners for network data changes
if (typeof window !== 'undefined') {
  // Listen for network data updates and invalidate React Query cache
  window.addEventListener('network-data-updated', () => {
    queryClient.invalidateQueries({ queryKey: ['/api', 'licenses'] });
  });

  // Listen for license updates and invalidate React Query cache
  window.addEventListener('licenses-updated', () => {
    queryClient.invalidateQueries({ queryKey: ['/api', 'licenses'] });
  });

  // Listen for database config changes and invalidate cache
  window.addEventListener('database-config-changed', () => {
    queryClient.invalidateQueries({ queryKey: ['/api', 'licenses'] });
  });
}
