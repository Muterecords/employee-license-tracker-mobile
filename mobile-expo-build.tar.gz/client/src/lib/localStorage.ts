import { type License, type InsertLicense } from "../shared/schema";
import { NetworkStorage, DatabaseConfig } from "./networkStorage";
import { changeLogger } from "./changeLogger";

const STORAGE_KEY = "license_manager_data";

interface StorageData {
  licenses: License[];
  nextId: number;
}

export class LocalStorageService {
  private networkStorage: NetworkStorage | null = null;
  private currentConfig: DatabaseConfig = {
    type: 'local',
    networkPath: '',
    autoSync: true,
    syncInterval: 5000
  };

  constructor() {
    this.loadConfiguration();
    this.setupEventListeners();
  }

  private loadConfiguration() {
    const savedConfig = localStorage.getItem('license-tracker-db-config');
    if (savedConfig) {
      try {
        this.currentConfig = JSON.parse(savedConfig);
        if (this.currentConfig.type === 'network') {
          this.networkStorage = new NetworkStorage(this.currentConfig);
        }
      } catch (error) {
        console.error('Error loading database configuration:', error);
      }
    }
  }

  private setupEventListeners() {
    window.addEventListener('database-config-changed', (event: any) => {
      const newConfig: DatabaseConfig = event.detail;
      this.updateConfiguration(newConfig);
    });

    window.addEventListener('network-data-updated', (event: any) => {
      // Trigger a refresh of the UI when network data changes
      window.dispatchEvent(new CustomEvent('licenses-updated', { detail: event.detail.licenses }));
    });
  }

  private updateConfiguration(newConfig: DatabaseConfig) {
    this.currentConfig = newConfig;
    
    if (this.networkStorage) {
      this.networkStorage.destroy();
      this.networkStorage = null;
    }

    if (newConfig.type === 'network') {
      this.networkStorage = new NetworkStorage(newConfig);
    }
  }
  private getStorageData(): StorageData {
    try {
      const data = localStorage.getItem(STORAGE_KEY);
      if (!data) {
        return { licenses: [], nextId: 1 };
      }
      return JSON.parse(data);
    } catch (error) {
      console.error("Error reading from localStorage:", error);
      return { licenses: [], nextId: 1 };
    }
  }

  private saveStorageData(data: StorageData): void {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (error) {
      console.error("Error saving to localStorage:", error);
      throw new Error("Failed to save data");
    }
  }

  private generateId(): string {
    const data = this.getStorageData();
    const id = `license_${data.nextId}`;
    data.nextId++;
    this.saveStorageData(data);
    return id;
  }

  async getAllLicenses(): Promise<License[]> {
    if (this.networkStorage && this.currentConfig.type === 'network') {
      return await this.networkStorage.getAllLicenses();
    }
    return this.getStorageData().licenses;
  }

  async getLicense(id: string): Promise<License | undefined> {
    if (this.networkStorage && this.currentConfig.type === 'network') {
      const licenses = await this.networkStorage.getAllLicenses();
      return licenses.find(license => license.id === id);
    }
    const data = this.getStorageData();
    return data.licenses.find(license => license.id === id);
  }

  async findLicenseByNumber(licenseNumber: string, excludeId?: string): Promise<License | undefined> {
    if (this.networkStorage && this.currentConfig.type === 'network') {
      const licenses = await this.networkStorage.getLicensesWithDuplicateNumber(licenseNumber, excludeId);
      return licenses[0]; // Return first duplicate found
    }
    const data = this.getStorageData();
    return data.licenses.find(license => 
      license.licenseNumber === licenseNumber && 
      license.id !== excludeId
    );
  }

  async createLicense(insertLicense: InsertLicense): Promise<License> {
    if (this.networkStorage && this.currentConfig.type === 'network') {
      return await this.networkStorage.createLicense(insertLicense);
    }
    
    const data = this.getStorageData();
    const newLicense: License = {
      ...insertLicense,
      id: this.generateId(),
      licenseNumber: insertLicense.licenseNumber ?? null,
      frontPhoto: insertLicense.frontPhoto ?? null,
      backPhoto: insertLicense.backPhoto ?? null,
      description: insertLicense.description ?? null,
    };
    
    data.licenses.push(newLicense);
    this.saveStorageData(data);
    
    // Log the change
    changeLogger.logLicenseAdded(newLicense);
    
    return newLicense;
  }

  async updateLicense(id: string, updateData: Partial<InsertLicense>): Promise<License | undefined> {
    if (this.networkStorage && this.currentConfig.type === 'network') {
      return await this.networkStorage.updateLicense(id, updateData);
    }
    
    const data = this.getStorageData();
    const index = data.licenses.findIndex(license => license.id === id);
    
    if (index === -1) {
      return undefined;
    }
    
    // Handle null values for photo fields
    const updatedLicense = {
      ...data.licenses[index],
      ...updateData,
      frontPhoto: updateData.frontPhoto !== undefined ? updateData.frontPhoto : data.licenses[index].frontPhoto,
      backPhoto: updateData.backPhoto !== undefined ? updateData.backPhoto : data.licenses[index].backPhoto,
    };
    
    // Store old license for logging
    const oldLicense = { ...data.licenses[index] };
    
    data.licenses[index] = updatedLicense;
    this.saveStorageData(data);
    
    // Log the change
    changeLogger.logLicenseUpdated(oldLicense, updatedLicense);
    
    return data.licenses[index];
  }

  async deleteLicense(id: string): Promise<boolean> {
    if (this.networkStorage && this.currentConfig.type === 'network') {
      return await this.networkStorage.deleteLicense(id);
    }
    
    const data = this.getStorageData();
    const index = data.licenses.findIndex(license => license.id === id);
    
    if (index === -1) {
      return false;
    }
    
    // Store license for logging before deletion
    const deletedLicense = { ...data.licenses[index] };
    
    data.licenses.splice(index, 1);
    this.saveStorageData(data);
    
    // Log the change
    changeLogger.logLicenseDeleted(deletedLicense);
    
    return true;
  }

  // Utility method to clear all data (for testing purposes)
  async clearAllData(): Promise<void> {
    localStorage.removeItem(STORAGE_KEY);
  }

  // Export data for backup
  exportData(): string {
    return JSON.stringify(this.getStorageData(), null, 2);
  }

  // Import data from backup
  importData(jsonData: string): void {
    try {
      const data = JSON.parse(jsonData);
      if (data.licenses && Array.isArray(data.licenses)) {
        this.saveStorageData(data);
      } else {
        throw new Error("Invalid data format");
      }
    } catch (error) {
      throw new Error("Failed to import data: " + error);
    }
  }
}

export const localStorageService = new LocalStorageService();