export function getDaysUntilExpiry(expiryDate: string): number {
  const expiry = new Date(expiryDate);
  const today = new Date();
  const diffTime = expiry.getTime() - today.getTime();
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

export function getLicenseStatus(expiryDate: string): 'active' | 'expiring' | 'expired' {
  const daysLeft = getDaysUntilExpiry(expiryDate);
  
  if (daysLeft < 0) return 'expired';
  if (daysLeft <= 30) return 'expiring';
  return 'active';
}

export function formatDate(dateString: string): string {
  return new Date(dateString).toLocaleDateString();
}

export function getStatusColor(status: string): string {
  switch (status) {
    case 'active':
      return 'bg-green-100 text-green-800';
    case 'expiring':
      return 'bg-amber-100 text-amber-800';
    case 'expired':
      return 'bg-red-100 text-red-800';
    default:
      return 'bg-gray-100 text-gray-800';
  }
}

export function getDaysLeftColor(daysLeft: number): string {
  if (daysLeft < 0) return 'text-red-600';
  if (daysLeft <= 30) return 'text-amber-600';
  return 'text-green-600';
}
