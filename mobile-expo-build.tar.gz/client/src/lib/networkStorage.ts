import { License, InsertLicense } from "../shared/schema";
import { changeLogger } from "./changeLogger";

export interface DatabaseConfig {
  type: 'local' | 'network';
  networkPath: string;
  autoSync: boolean;
  syncInterval: number;
}

export interface StorageData {
  licenses: License[];
  lastModified: number;
  version: number;
}

export interface OfflineOperation {
  id: string;
  type: 'create' | 'update' | 'delete';
  data: any;
  timestamp: number;
  networkPath: string;
  retryCount: number;
  lastRetryTime?: number;
  originalData?: any; // For conflict resolution
}

export interface ReplayProgress {
  total: number;
  completed: number;
  failed: number;
  currentOperation?: string;
}

export interface ConflictResolution {
  operation: OfflineOperation;
  serverData: any;
  clientData: any;
  resolution: 'server' | 'client' | 'merge' | 'skip';
}

export class NetworkStorage {
  private config: DatabaseConfig;
  private syncTimer: NodeJS.Timeout | null = null;
  private lastSyncTime: number = 0;
  private isOnline: boolean = true;
  private replayInProgress: boolean = false;
  private retryDelays = [1000, 2000, 4000, 8000, 16000]; // Exponential backoff
  private maxRetries = 5;
  private offlineQueueKey = 'offline-operations-v2';

  constructor(config: DatabaseConfig) {
    this.config = config;
    this.startAutoSync();
    this.setupConnectivityListener();
    // Auto-replay on initialization if online
    if (this.config.type === 'network') {
      setTimeout(() => this.attemptOfflineReplay(), 1000);
    }
  }

  updateConfig(newConfig: DatabaseConfig) {
    this.config = newConfig;
    this.stopAutoSync();
    this.startAutoSync();
  }

  private startAutoSync() {
    if (this.config.type === 'network' && this.config.autoSync) {
      this.syncTimer = setInterval(() => {
        this.checkForUpdates();
      }, this.config.syncInterval);
    }
  }

  private stopAutoSync() {
    if (this.syncTimer) {
      clearInterval(this.syncTimer);
      this.syncTimer = null;
    }
  }

  private async checkForUpdates() {
    if (this.config.type !== 'network') return;

    try {
      const response = await fetch('/api/network-db/check-updates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          path: this.config.networkPath,
          lastSync: this.lastSyncTime
        })
      });

      if (response.ok) {
        const result = await response.json();
        if (result.hasUpdates) {
          // Compare old and new data to detect specific changes
          const oldLicenses = this.getCachedNetworkLicenses();
          const newLicenses = result.data.licenses || [];
          const changes = this.detectChanges(oldLicenses, newLicenses);
          
          // Notify components that data has changed
          window.dispatchEvent(new CustomEvent('network-data-updated', { 
            detail: { 
              data: result.data,
              changes: changes
            }
          }));
          
          // Show specific notifications for each change
          this.showChangeNotifications(changes);
          
          // Log network changes from other users
          this.logNetworkChanges(changes);
        }
        this.lastSyncTime = Date.now();
        
        if (!this.isOnline) {
          this.isOnline = true;
          this.notifyConnectionStatus(true);
        }
      } else {
        throw new Error('Failed to check updates');
      }
    } catch (error) {
      console.warn('Network sync failed:', error);
      if (this.isOnline) {
        this.isOnline = false;
        this.notifyConnectionStatus(false);
      }
    }
  }

  private notifyConnectionStatus(online: boolean) {
    window.dispatchEvent(new CustomEvent('network-status-changed', { 
      detail: { online, message: online ? 'Connected to network database' : 'Working offline - network database unavailable' }
    }));
  }

  private detectChanges(oldLicenses: License[], newLicenses: License[]): Array<{type: 'added' | 'updated' | 'deleted', license: License, details?: string}> {
    const changes: Array<{type: 'added' | 'updated' | 'deleted', license: License, details?: string}> = [];
    
    // Create maps for faster lookup
    const oldMap = new Map(oldLicenses.map(l => [l.id, l]));
    const newMap = new Map(newLicenses.map(l => [l.id, l]));
    
    // Check for added licenses
    for (const newLicense of newLicenses) {
      if (!oldMap.has(newLicense.id)) {
        changes.push({
          type: 'added',
          license: newLicense
        });
      }
    }
    
    // Check for updated licenses
    for (const newLicense of newLicenses) {
      const oldLicense = oldMap.get(newLicense.id);
      if (oldLicense && this.hasLicenseChanged(oldLicense, newLicense)) {
        const details = this.getChangeDetails(oldLicense, newLicense);
        changes.push({
          type: 'updated',
          license: newLicense,
          details: details
        });
      }
    }
    
    // Check for deleted licenses
    for (const oldLicense of oldLicenses) {
      if (!newMap.has(oldLicense.id)) {
        changes.push({
          type: 'deleted',
          license: oldLicense
        });
      }
    }
    
    return changes;
  }

  private hasLicenseChanged(oldLicense: License, newLicense: License): boolean {
    return JSON.stringify(oldLicense) !== JSON.stringify(newLicense);
  }

  private getChangeDetails(oldLicense: License, newLicense: License): string {
    const changes: string[] = [];
    
    if (oldLicense.name !== newLicense.name) changes.push('name');
    if (oldLicense.type !== newLicense.type) changes.push('type');
    if (oldLicense.licenseNumber !== newLicense.licenseNumber) changes.push('license number');
    if (oldLicense.expiryDate !== newLicense.expiryDate) changes.push('expiry date');
    if (oldLicense.description !== newLicense.description) changes.push('description');
    if (oldLicense.frontPhoto !== newLicense.frontPhoto || oldLicense.backPhoto !== newLicense.backPhoto) changes.push('photos');
    
    return changes.length > 0 ? `Updated: ${changes.join(', ')}` : 'Updated';
  }

  private showChangeNotifications(changes: Array<{type: 'added' | 'updated' | 'deleted', license: License, details?: string}>) {
    // Dispatch notification events that the UI can listen to
    for (const change of changes) {
      let title = '';
      let description = '';
      
      switch (change.type) {
        case 'added':
          title = '📋 License Added';
          description = `${change.license.name} (${change.license.type}) has been added to the database`;
          break;
        case 'updated':
          title = '✏️ License Updated';
          description = `${change.license.name} (${change.license.type}) has been modified${change.details ? ': ' + change.details : ''}`;
          break;
        case 'deleted':
          title = '🗑️ License Removed';
          description = `${change.license.name} (${change.license.type}) has been removed from the database`;
          break;
      }
      
      // Dispatch custom event for toast notifications
      window.dispatchEvent(new CustomEvent('license-change-notification', {
        detail: {
          title,
          description,
          type: change.type,
          license: change.license
        }
      }));
    }
  }

  private logNetworkChanges(changes: Array<{type: 'added' | 'updated' | 'deleted', license: License, details?: string}>) {
    // Log changes detected from network (other users)
    for (const change of changes) {
      switch (change.type) {
        case 'added':
          changeLogger.logLicenseAdded(change.license);
          break;
        case 'updated':
          // For network updates, we don't have the old license data, so log with current data
          changeLogger.logLicenseUpdated(change.license, change.license);
          break;
        case 'deleted':
          changeLogger.logLicenseDeleted(change.license);
          break;
      }
    }
  }

  async getAllLicenses(): Promise<License[]> {
    if (this.config.type === 'local') {
      return this.getLocalLicenses();
    } else {
      return this.getNetworkLicenses();
    }
  }

  private getLocalLicenses(): License[] {
    const data = localStorage.getItem('license-tracker-data');
    if (!data) return [];
    
    try {
      const parsed = JSON.parse(data);
      return parsed.licenses || [];
    } catch {
      return [];
    }
  }

  private async getNetworkLicenses(): Promise<License[]> {
    try {
      const response = await fetch('/api/network-db/read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: this.config.networkPath })
      });

      if (response.ok) {
        const data = await response.json();
        this.lastSyncTime = Date.now();
        
        if (!this.isOnline) {
          this.isOnline = true;
          this.notifyConnectionStatus(true);
        }
        
        return data.licenses || [];
      } else {
        // Fallback to cached local data if network fails
        if (this.isOnline) {
          this.isOnline = false;
          this.notifyConnectionStatus(false);
        }
        return this.getCachedNetworkLicenses();
      }
    } catch (error) {
      console.warn('Failed to read network database:', error);
      if (this.isOnline) {
        this.isOnline = false;
        this.notifyConnectionStatus(false);
      }
      return this.getCachedNetworkLicenses();
    }
  }

  private getCachedNetworkLicenses(): License[] {
    const cached = localStorage.getItem(`network-cache-${this.config.networkPath}`);
    if (cached) {
      try {
        const data = JSON.parse(cached);
        return data.licenses || [];
      } catch {
        return [];
      }
    }
    return [];
  }

  async createLicense(insertLicense: InsertLicense): Promise<License> {
    const newLicense: License = {
      ...insertLicense,
      id: this.generateId(),
      licenseNumber: insertLicense.licenseNumber ?? null,
      frontPhoto: insertLicense.frontPhoto ?? null,
      backPhoto: insertLicense.backPhoto ?? null,
      description: insertLicense.description ?? null,
    };

    if (this.config.type === 'local') {
      return this.createLocalLicense(newLicense);
    } else {
      return this.createNetworkLicense(newLicense);
    }
  }

  private createLocalLicense(license: License): License {
    const data = this.getLocalStorageData();
    data.licenses.push(license);
    this.saveLocalStorageData(data);
    return license;
  }

  private async createNetworkLicense(license: License): Promise<License> {
    try {
      const response = await fetch('/api/network-db/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          path: this.config.networkPath,
          license: license
        })
      });

      if (response.ok) {
        const result = await response.json();
        this.updateNetworkCache(result.data);
        
        // Log the change
        changeLogger.logLicenseAdded(license);
        
        return license;
      } else {
        throw new Error('Failed to create license in network database');
      }
    } catch (error) {
      // Fallback to local cache
      console.warn('Network create failed, using local cache:', error);
      this.createLocalLicense(license);
      this.queueOfflineOperation('create', license);
      return license;
    }
  }

  async updateLicense(id: string, updateData: Partial<InsertLicense>): Promise<License | undefined> {
    if (this.config.type === 'local') {
      return this.updateLocalLicense(id, updateData);
    } else {
      return this.updateNetworkLicense(id, updateData);
    }
  }

  private updateLocalLicense(id: string, updateData: Partial<InsertLicense>): License | undefined {
    const data = this.getLocalStorageData();
    const index = data.licenses.findIndex(license => license.id === id);
    
    if (index === -1) return undefined;
    
    const updatedLicense = {
      ...data.licenses[index],
      ...updateData,
      frontPhoto: updateData.frontPhoto !== undefined ? updateData.frontPhoto : data.licenses[index].frontPhoto,
      backPhoto: updateData.backPhoto !== undefined ? updateData.backPhoto : data.licenses[index].backPhoto,
    };
    
    data.licenses[index] = updatedLicense;
    this.saveLocalStorageData(data);
    return updatedLicense;
  }

  private async updateNetworkLicense(id: string, updateData: Partial<InsertLicense>): Promise<License | undefined> {
    try {
      // Get old license data for logging
      const currentLicenses = await this.getAllLicenses();
      const oldLicense = currentLicenses.find(l => l.id === id);
      
      const response = await fetch('/api/network-db/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          path: this.config.networkPath,
          id: id,
          updateData: updateData
        })
      });

      if (response.ok) {
        const result = await response.json();
        this.updateNetworkCache(result.data);
        
        // Log the change
        if (oldLicense && result.license) {
          changeLogger.logLicenseUpdated(oldLicense, result.license);
        }
        
        return result.license;
      } else {
        throw new Error('Failed to update license in network database');
      }
    } catch (error) {
      // Fallback to local cache
      console.warn('Network update failed, using local cache:', error);
      const updated = this.updateLocalLicense(id, updateData);
      if (updated) {
        this.queueOfflineOperation('update', { id, ...updateData });
      }
      return updated;
    }
  }

  async deleteLicense(id: string): Promise<boolean> {
    if (this.config.type === 'local') {
      return this.deleteLocalLicense(id);
    } else {
      return this.deleteNetworkLicense(id);
    }
  }

  private deleteLocalLicense(id: string): boolean {
    const data = this.getLocalStorageData();
    const index = data.licenses.findIndex(license => license.id === id);
    
    if (index === -1) return false;
    
    data.licenses.splice(index, 1);
    this.saveLocalStorageData(data);
    return true;
  }

  private async deleteNetworkLicense(id: string): Promise<boolean> {
    try {
      // Get license data for logging before deletion
      const currentLicenses = await this.getAllLicenses();
      const licenseToDelete = currentLicenses.find(l => l.id === id);
      
      const response = await fetch('/api/network-db/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          path: this.config.networkPath,
          id: id
        })
      });

      if (response.ok) {
        const result = await response.json();
        this.updateNetworkCache(result.data);
        
        // Log the change
        if (licenseToDelete) {
          changeLogger.logLicenseDeleted(licenseToDelete);
        }
        
        return true;
      } else {
        throw new Error('Failed to delete license from network database');
      }
    } catch (error) {
      // Fallback to local cache
      console.warn('Network delete failed, using local cache:', error);
      const success = this.deleteLocalLicense(id);
      if (success) {
        this.queueOfflineOperation('delete', { id });
      }
      return success;
    }
  }

  private updateNetworkCache(data: StorageData) {
    localStorage.setItem(`network-cache-${this.config.networkPath}`, JSON.stringify(data));
  }

  private setupConnectivityListener() {
    // Listen for online/offline events
    window.addEventListener('online', () => {
      console.log('Network connectivity restored');
      this.isOnline = true;
      this.notifyConnectionStatus(true);
      setTimeout(() => this.attemptOfflineReplay(), 500);
    });

    window.addEventListener('offline', () => {
      console.log('Network connectivity lost');
      this.isOnline = false;
      this.notifyConnectionStatus(false);
    });
  }

  private generateOperationId(): string {
    return `op_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private queueOfflineOperation(type: 'create' | 'update' | 'delete', data: any, originalData?: any) {
    const queue = this.getOfflineOperationQueue();
    const operation: OfflineOperation = {
      id: this.generateOperationId(),
      type,
      data,
      timestamp: Date.now(),
      networkPath: this.config.networkPath,
      retryCount: 0,
      originalData
    };
    
    queue.push(operation);
    this.saveOfflineOperationQueue(queue);
    
    // Notify about queued operation
    this.notifyReplayProgress({
      total: queue.length,
      completed: 0,
      failed: 0,
      currentOperation: `Queued ${type} operation`
    });
    
    console.log(`Queued offline operation: ${type}`, operation);
  }

  private getOfflineOperationQueue(): OfflineOperation[] {
    try {
      const queueData = localStorage.getItem(this.offlineQueueKey);
      if (!queueData) return [];
      const parsed = JSON.parse(queueData);
      return Array.isArray(parsed) ? parsed : [];
    } catch (error) {
      console.error('Error reading offline operation queue:', error);
      return [];
    }
  }

  private saveOfflineOperationQueue(queue: OfflineOperation[]) {
    try {
      localStorage.setItem(this.offlineQueueKey, JSON.stringify(queue));
    } catch (error) {
      console.error('Error saving offline operation queue:', error);
    }
  }

  private removeOperationFromQueue(operationId: string) {
    const queue = this.getOfflineOperationQueue();
    const filteredQueue = queue.filter(op => op.id !== operationId);
    this.saveOfflineOperationQueue(filteredQueue);
  }

  private updateOperationInQueue(operationId: string, updates: Partial<OfflineOperation>) {
    const queue = this.getOfflineOperationQueue();
    const operationIndex = queue.findIndex(op => op.id === operationId);
    if (operationIndex !== -1) {
      queue[operationIndex] = { ...queue[operationIndex], ...updates };
      this.saveOfflineOperationQueue(queue);
    }
  }

  private getLocalStorageData(): StorageData {
    const data = localStorage.getItem('license-tracker-data');
    if (!data) {
      return { licenses: [], lastModified: Date.now(), version: 1 };
    }
    
    try {
      return JSON.parse(data);
    } catch {
      return { licenses: [], lastModified: Date.now(), version: 1 };
    }
  }

  private saveLocalStorageData(data: StorageData) {
    data.lastModified = Date.now();
    data.version = (data.version || 0) + 1;
    localStorage.setItem('license-tracker-data', JSON.stringify(data));
  }

  private generateId(): string {
    return Math.random().toString(36).substr(2, 9);
  }

  async getLicensesWithDuplicateNumber(licenseNumber: string, excludeId?: string): Promise<License[]> {
    const licenses = await this.getAllLicenses();
    return licenses.filter(license => 
      license.licenseNumber === licenseNumber && 
      license.id !== excludeId
    );
  }

  private notifyReplayProgress(progress: ReplayProgress) {
    window.dispatchEvent(new CustomEvent('offline-replay-progress', {
      detail: progress
    }));
  }

  private notifyConflictResolution(conflict: ConflictResolution) {
    window.dispatchEvent(new CustomEvent('offline-conflict-detected', {
      detail: conflict
    }));
  }

  async attemptOfflineReplay(): Promise<void> {
    if (this.replayInProgress || this.config.type !== 'network' || !this.isOnline) {
      return;
    }

    const queue = this.getOfflineOperationQueue();
    if (queue.length === 0) {
      return;
    }

    console.log(`Starting offline replay of ${queue.length} operations`);
    this.replayInProgress = true;

    let completed = 0;
    let failed = 0;
    const total = queue.length;

    // Filter operations for current network path
    const relevantOperations = queue.filter(op => op.networkPath === this.config.networkPath);
    
    for (const operation of relevantOperations) {
      try {
        this.notifyReplayProgress({
          total,
          completed,
          failed,
          currentOperation: `Replaying ${operation.type}: ${operation.data.name || operation.id}`
        });

        const success = await this.replayOperation(operation);
        
        if (success) {
          this.removeOperationFromQueue(operation.id);
          completed++;
          console.log(`Successfully replayed operation: ${operation.id}`);
          
          // Show notification for successfully synced offline change
          this.showOfflineReplayNotification(operation);
        } else {
          failed++;
          // Update retry count and schedule for retry if under limit
          if (operation.retryCount < this.maxRetries) {
            this.updateOperationInQueue(operation.id, {
              retryCount: operation.retryCount + 1,
              lastRetryTime: Date.now()
            });
            console.log(`Operation ${operation.id} failed, will retry later (${operation.retryCount + 1}/${this.maxRetries})`);
          } else {
            console.error(`Operation ${operation.id} failed permanently after ${this.maxRetries} retries`);
            this.removeOperationFromQueue(operation.id);
            failed++;
          }
        }
      } catch (error) {
        console.error(`Error replaying operation ${operation.id}:`, error);
        failed++;
      }
    }

    this.notifyReplayProgress({
      total,
      completed,
      failed,
      currentOperation: completed > 0 ? `Completed: ${completed} operations synced` : 'Sync completed'
    });

    this.replayInProgress = false;
    console.log(`Offline replay completed: ${completed} successful, ${failed} failed`);
    
    // Show summary notification if any operations were synced
    if (completed > 0) {
      window.dispatchEvent(new CustomEvent('license-change-notification', {
        detail: {
          title: '✅ Offline Changes Synced',
          description: `${completed} offline change${completed > 1 ? 's' : ''} successfully synced to network database`,
          type: 'sync'
        }
      }));
    }
  }

  private showOfflineReplayNotification(operation: OfflineOperation) {
    let title = '';
    let description = '';
    const licenseName = operation.data.name || 'Unknown License';
    const licenseType = operation.data.type || '';
    
    switch (operation.type) {
      case 'create':
        title = '📤 Offline License Synced';
        description = `${licenseName} (${licenseType}) was created while offline and has now been synced`;
        break;
      case 'update':
        title = '📤 Offline Update Synced';
        description = `Changes to ${licenseName} (${licenseType}) made while offline have been synced`;
        break;
      case 'delete':
        title = '📤 Offline Deletion Synced';
        description = `${licenseName} (${licenseType}) was deleted while offline and has now been synced`;
        break;
    }
    
    // Dispatch notification event
    window.dispatchEvent(new CustomEvent('license-change-notification', {
      detail: {
        title,
        description,
        type: 'offline-sync',
        license: operation.data
      }
    }));
  }

  private async replayOperation(operation: OfflineOperation): Promise<boolean> {
    try {
      switch (operation.type) {
        case 'create':
          return await this.replayCreateOperation(operation);
        case 'update':
          return await this.replayUpdateOperation(operation);
        case 'delete':
          return await this.replayDeleteOperation(operation);
        default:
          console.error(`Unknown operation type: ${operation.type}`);
          return false;
      }
    } catch (error) {
      console.error(`Failed to replay ${operation.type} operation:`, error);
      return false;
    }
  }

  private async replayCreateOperation(operation: OfflineOperation): Promise<boolean> {
    try {
      const response = await fetch('/api/network-db/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          path: this.config.networkPath,
          license: operation.data
        })
      });

      if (response.ok) {
        const result = await response.json();
        this.updateNetworkCache(result.data);
        return true;
      } else {
        const errorData = await response.json();
        // Handle duplicate license number conflicts
        if (errorData.error?.includes('already exists')) {
          return await this.handleCreateConflict(operation, errorData);
        }
        return false;
      }
    } catch (error) {
      console.error('Failed to replay create operation:', error);
      return false;
    }
  }

  private async replayUpdateOperation(operation: OfflineOperation): Promise<boolean> {
    try {
      const response = await fetch('/api/network-db/update', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          path: this.config.networkPath,
          id: operation.data.id,
          updateData: operation.data
        })
      });

      if (response.ok) {
        const result = await response.json();
        this.updateNetworkCache(result.data);
        return true;
      } else {
        const errorData = await response.json();
        // Handle conflicts (e.g., record not found, modified by another user)
        if (errorData.error?.includes('not found')) {
          console.warn(`Record ${operation.data.id} not found during update replay - may have been deleted`);
          return true; // Consider this resolved
        }
        return await this.handleUpdateConflict(operation, errorData);
      }
    } catch (error) {
      console.error('Failed to replay update operation:', error);
      return false;
    }
  }

  private async replayDeleteOperation(operation: OfflineOperation): Promise<boolean> {
    try {
      const response = await fetch('/api/network-db/delete', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          path: this.config.networkPath,
          id: operation.data.id
        })
      });

      if (response.ok) {
        const result = await response.json();
        this.updateNetworkCache(result.data);
        return true;
      } else {
        const errorData = await response.json();
        // Handle case where record was already deleted
        if (errorData.error?.includes('not found')) {
          console.warn(`Record ${operation.data.id} already deleted`);
          return true; // Consider this resolved
        }
        return false;
      }
    } catch (error) {
      console.error('Failed to replay delete operation:', error);
      return false;
    }
  }

  private async handleCreateConflict(operation: OfflineOperation, errorData: any): Promise<boolean> {
    const conflict: ConflictResolution = {
      operation,
      serverData: null,
      clientData: operation.data,
      resolution: 'skip' // Default resolution for create conflicts
    };

    this.notifyConflictResolution(conflict);
    console.warn(`Create conflict detected for license ${operation.data.licenseNumber}: ${errorData.error}`);
    return true; // Consider resolved by skipping
  }

  private async handleUpdateConflict(operation: OfflineOperation, errorData: any): Promise<boolean> {
    // For update conflicts, we could implement more sophisticated resolution
    // For now, we'll use a simple strategy: prefer client changes
    const conflict: ConflictResolution = {
      operation,
      serverData: null,
      clientData: operation.data,
      resolution: 'client'
    };

    this.notifyConflictResolution(conflict);
    console.warn(`Update conflict detected: ${errorData.error}`);
    return false; // Let it retry or fail permanently
  }

  // Public method to manually trigger replay
  async forceOfflineReplay(): Promise<void> {
    await this.attemptOfflineReplay();
  }

  // Public method to get current offline queue status
  getOfflineQueueStatus(): { count: number; operations: OfflineOperation[] } {
    const queue = this.getOfflineOperationQueue();
    const relevantOperations = queue.filter(op => op.networkPath === this.config.networkPath);
    return {
      count: relevantOperations.length,
      operations: relevantOperations
    };
  }

  // Public method to clear all offline operations (for testing/emergency)
  clearOfflineQueue(): void {
    localStorage.removeItem(this.offlineQueueKey);
    this.notifyReplayProgress({
      total: 0,
      completed: 0,
      failed: 0,
      currentOperation: 'Queue cleared'
    });
  }

  destroy() {
    this.stopAutoSync();
    // Clean up event listeners
    window.removeEventListener('online', () => {});
    window.removeEventListener('offline', () => {});
  }
}