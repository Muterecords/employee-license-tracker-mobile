import { License } from "../shared/schema";

export interface LogEntry {
  id: string;
  timestamp: number;
  date: string;
  time: string;
  action: 'NEW LICENCE ADDED' | 'LICENCE UPDATED' | 'LICENCE DELETED';
  employeeName: string;
  licenseType: string;
  details?: string;
  user?: string; // For future multi-user identification
}

class ChangeLogger {
  private readonly LOG_STORAGE_KEY = 'license_change_logs';

  private formatDateTime(timestamp: number = Date.now()): { date: string; time: string } {
    const now = new Date(timestamp);
    const date = now.toLocaleDateString('en-GB', {
      day: '2-digit',
      month: '2-digit', 
      year: 'numeric'
    });
    const time = now.toLocaleTimeString('en-GB', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    });
    
    return { date, time };
  }

  private generateLogId(): string {
    return `log_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private saveLogs(logs: LogEntry[]): void {
    try {
      localStorage.setItem(this.LOG_STORAGE_KEY, JSON.stringify(logs));
    } catch (error) {
      console.error('Failed to save logs:', error);
    }
  }

  private getLogs(): LogEntry[] {
    try {
      const logs = localStorage.getItem(this.LOG_STORAGE_KEY);
      return logs ? JSON.parse(logs) : [];
    } catch (error) {
      console.error('Failed to load logs:', error);
      return [];
    }
  }

  logLicenseAdded(license: License): void {
    const { date, time } = this.formatDateTime();
    const logEntry: LogEntry = {
      id: this.generateLogId(),
      timestamp: Date.now(),
      date,
      time,
      action: 'NEW LICENCE ADDED',
      employeeName: license.name,
      licenseType: license.type,
    };

    const logs = this.getLogs();
    logs.unshift(logEntry); // Add to beginning for newest first
    this.saveLogs(logs);

    console.log(`[${date}:(${time})] NEW LICENCE ADDED - ${license.name} : ${license.type}`);
  }

  logLicenseUpdated(oldLicense: License, newLicense: License): void {
    const { date, time } = this.formatDateTime();
    
    // Determine what changed
    const changes: string[] = [];
    if (oldLicense.name !== newLicense.name) changes.push('name');
    if (oldLicense.type !== newLicense.type) changes.push('type');
    if (oldLicense.licenseNumber !== newLicense.licenseNumber) changes.push('license number');
    if (oldLicense.expiryDate !== newLicense.expiryDate) changes.push('expiry date');
    if (oldLicense.description !== newLicense.description) changes.push('description');
    if (oldLicense.frontPhoto !== newLicense.frontPhoto || oldLicense.backPhoto !== newLicense.backPhoto) changes.push('photos');

    const details = changes.length > 0 ? `Updated: ${changes.join(', ')}` : 'Updated';

    const logEntry: LogEntry = {
      id: this.generateLogId(),
      timestamp: Date.now(),
      date,
      time,
      action: 'LICENCE UPDATED',
      employeeName: newLicense.name,
      licenseType: newLicense.type,
      details,
    };

    const logs = this.getLogs();
    logs.unshift(logEntry);
    this.saveLogs(logs);

    console.log(`[${date}:(${time})] LICENCE UPDATED - ${newLicense.name} : ${newLicense.type} (${details})`);
  }

  logLicenseDeleted(license: License): void {
    const { date, time } = this.formatDateTime();
    const logEntry: LogEntry = {
      id: this.generateLogId(),
      timestamp: Date.now(),
      date,
      time,
      action: 'LICENCE DELETED',
      employeeName: license.name,
      licenseType: license.type,
    };

    const logs = this.getLogs();
    logs.unshift(logEntry);
    this.saveLogs(logs);

    console.log(`[${date}:(${time})] LICENCE DELETED - ${license.name} : ${license.type}`);
  }

  getAllLogs(): LogEntry[] {
    return this.getLogs();
  }

  getLogsFromDate(fromDate: Date): LogEntry[] {
    const logs = this.getLogs();
    const fromTimestamp = fromDate.getTime();
    return logs.filter(log => log.timestamp >= fromTimestamp);
  }

  clearLogs(): void {
    localStorage.removeItem(this.LOG_STORAGE_KEY);
  }

  exportLogs(): string {
    const logs = this.getLogs();
    return logs.map(log => 
      `[${log.date}:(${log.time})] ${log.action} - ${log.employeeName} : ${log.licenseType}${log.details ? ` (${log.details})` : ''}`
    ).join('\n');
  }
}

export const changeLogger = new ChangeLogger();