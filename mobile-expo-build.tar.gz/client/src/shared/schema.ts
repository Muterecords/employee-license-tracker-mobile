import { sql } from "drizzle-orm";
import { pgTable, text, varchar, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const licenses = pgTable("licenses", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  type: text("type").notNull(),
  licenseNumber: text("license_number"),
  frontPhoto: text("front_photo"), // Base64 encoded image
  backPhoto: text("back_photo"), // Base64 encoded image
  expiryDate: date("expiry_date").notNull(),
  description: text("description"),
});

export const insertLicenseSchema = createInsertSchema(licenses).omit({
  id: true,
}).extend({
  expiryDate: z.string().refine((date) => {
    const parsed = new Date(date);
    return !isNaN(parsed.getTime()) && parsed > new Date();
  }, "Expiry date must be a valid future date"),
});

export type InsertLicense = z.infer<typeof insertLicenseSchema>;
export type License = typeof licenses.$inferSelect;
