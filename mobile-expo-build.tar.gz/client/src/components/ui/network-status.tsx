import { useState, useEffect } from "react";
import { Badge } from "./badge";
import { Button } from "./button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./card";
import { Progress } from "./progress";
import { Alert, AlertDescription } from "./alert";
import { Wifi, WifiOff, Database, AlertCircle, CheckCircle, Clock, RefreshCw } from "lucide-react";
import type { ReplayProgress, ConflictResolution, OfflineOperation } from '@/lib/networkStorage';

interface NetworkStatusProps {
  className?: string;
  networkStorage?: any; // NetworkStorage instance
  showDetails?: boolean;
}

export default function NetworkStatus({ className = "", networkStorage, showDetails = false }: NetworkStatusProps) {
  const [isOnline, setIsOnline] = useState(true);
  const [message, setMessage] = useState('Local Database');
  const [dbType, setDbType] = useState<'local' | 'network'>('local');
  const [replayProgress, setReplayProgress] = useState<ReplayProgress | null>(null);
  const [conflicts, setConflicts] = useState<ConflictResolution[]>([]);
  const [offlineQueue, setOfflineQueue] = useState<{ count: number; operations: OfflineOperation[] }>({ count: 0, operations: [] });
  const [isReplaying, setIsReplaying] = useState(false);

  useEffect(() => {
    // Load initial configuration
    const loadConfig = () => {
      const savedConfig = localStorage.getItem('license-tracker-db-config');
      if (savedConfig) {
        try {
          const config = JSON.parse(savedConfig);
          setDbType(config.type);
          if (config.type === 'local') {
            setMessage('Local Database');
            setIsOnline(true);
          } else {
            setMessage('Network Database');
            setIsOnline(true); // Will be updated by network status events
          }
        } catch (error) {
          console.error('Error loading config:', error);
        }
      }
    };

    loadConfig();

    // Listen for network status changes
    const handleNetworkStatus = (event: any) => {
      setIsOnline(event.detail.online);
      setMessage(event.detail.message);
    };

    // Listen for database config changes
    const handleConfigChange = (event: any) => {
      const config = event.detail;
      setDbType(config.type);
      if (config.type === 'local') {
        setMessage('Local Database');
        setIsOnline(true);
      } else {
        setMessage('Network Database - Connecting...');
        setIsOnline(true); // Will be updated by network status events
      }
    };

    // Listen for replay progress
    const handleReplayProgress = (event: CustomEvent) => {
      const progress: ReplayProgress = event.detail;
      setReplayProgress(progress);
      setIsReplaying(progress.total > 0 && progress.completed + progress.failed < progress.total);
      
      // Update offline queue status
      if (networkStorage) {
        setOfflineQueue(networkStorage.getOfflineQueueStatus());
      }
    };

    // Listen for conflicts
    const handleConflict = (event: CustomEvent) => {
      const conflict: ConflictResolution = event.detail;
      setConflicts(prev => [...prev, conflict]);
    };

    // Listen for license updates to refresh queue status
    const handleLicenseUpdate = () => {
      if (networkStorage) {
        setOfflineQueue(networkStorage.getOfflineQueueStatus());
      }
    };

    window.addEventListener('network-status-changed', handleNetworkStatus);
    window.addEventListener('database-config-changed', handleConfigChange);
    window.addEventListener('offline-replay-progress', handleReplayProgress as EventListener);
    window.addEventListener('offline-conflict-detected', handleConflict as EventListener);
    window.addEventListener('licenses-updated', handleLicenseUpdate);
    window.addEventListener('network-data-updated', handleLicenseUpdate);

    // Initial status check
    if (networkStorage) {
      setOfflineQueue(networkStorage.getOfflineQueueStatus());
    }

    return () => {
      window.removeEventListener('network-status-changed', handleNetworkStatus);
      window.removeEventListener('database-config-changed', handleConfigChange);
      window.removeEventListener('offline-replay-progress', handleReplayProgress as EventListener);
      window.removeEventListener('offline-conflict-detected', handleConflict as EventListener);
      window.removeEventListener('licenses-updated', handleLicenseUpdate);
      window.removeEventListener('network-data-updated', handleLicenseUpdate);
    };
  }, []);

  const handleForceSync = async () => {
    if (networkStorage && !isReplaying) {
      setIsReplaying(true);
      try {
        await networkStorage.forceOfflineReplay();
      } catch (error) {
        console.error('Force sync failed:', error);
      }
    }
  };

  const handleClearQueue = () => {
    if (networkStorage && !isReplaying) {
      networkStorage.clearOfflineQueue();
      setOfflineQueue({ count: 0, operations: [] });
      setReplayProgress(null);
      setConflicts([]);
    }
  };

  const dismissConflict = (index: number) => {
    setConflicts(prev => prev.filter((_, i) => i !== index));
  };

  // Simple badge view (default)
  if (!showDetails) {
    if (dbType === 'local') {
      return (
        <Badge variant="outline" className={`flex items-center gap-1 ${className}`}>
          <Database size={12} />
          Local
          {offlineQueue.count > 0 && (
            <span className="ml-1 text-xs bg-red-500 text-white rounded-full px-1">
              {offlineQueue.count}
            </span>
          )}
        </Badge>
      );
    }

    return (
      <Badge 
        variant={isOnline ? "default" : "destructive"} 
        className={`flex items-center gap-1 ${className}`}
        data-testid="network-status-badge"
      >
        {isOnline ? <Wifi size={12} /> : <WifiOff size={12} />}
        {isOnline ? "Network" : "Offline"}
        {offlineQueue.count > 0 && (
          <span className="ml-1 text-xs bg-yellow-500 text-white rounded-full px-1">
            {offlineQueue.count}
          </span>
        )}
      </Badge>
    );
  }

  // Detailed card view
  return (
    <Card className={`w-full ${className}`} data-testid="network-status-card">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2">
          {dbType === 'local' ? (
            <Database className="h-4 w-4 text-blue-500" />
          ) : isOnline ? (
            <Wifi className="h-4 w-4 text-green-500" data-testid="icon-online" />
          ) : (
            <WifiOff className="h-4 w-4 text-red-500" data-testid="icon-offline" />
          )}
          Network Status
        </CardTitle>
        <CardDescription>
          {message}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Connection Status */}
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium">Connection:</span>
          <Badge variant={isOnline ? 'default' : 'secondary'} data-testid="badge-connection-status">
            {dbType === 'local' ? 'Local' : isOnline ? 'Online' : 'Offline'}
          </Badge>
        </div>

        {/* Offline Queue Status */}
        {dbType === 'network' && (
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Pending Operations:</span>
            <Badge variant={offlineQueue.count > 0 ? 'destructive' : 'outline'} data-testid="badge-queue-count">
              <Clock className="h-3 w-3 mr-1" />
              {offlineQueue.count}
            </Badge>
          </div>
        )}

        {/* Replay Progress */}
        {replayProgress && replayProgress.total > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-medium">Sync Progress:</span>
              <span data-testid="text-sync-progress">
                {replayProgress.completed + replayProgress.failed}/{replayProgress.total}
              </span>
            </div>
            <Progress 
              value={((replayProgress.completed + replayProgress.failed) / replayProgress.total) * 100}
              className="h-2"
              data-testid="progress-sync"
            />
            {replayProgress.currentOperation && (
              <p className="text-xs text-muted-foreground" data-testid="text-current-operation">
                {replayProgress.currentOperation}
              </p>
            )}
            {replayProgress.failed > 0 && (
              <p className="text-xs text-red-600" data-testid="text-failed-operations">
                {replayProgress.failed} operations failed
              </p>
            )}
          </div>
        )}

        {/* Action Buttons */}
        {dbType === 'network' && (
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleForceSync}
              disabled={!networkStorage || isReplaying || offlineQueue.count === 0}
              data-testid="button-force-sync"
            >
              <RefreshCw className={`h-3 w-3 mr-1 ${isReplaying ? 'animate-spin' : ''}`} />
              Force Sync
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              onClick={handleClearQueue}
              disabled={!networkStorage || isReplaying || offlineQueue.count === 0}
              data-testid="button-clear-queue"
            >
              Clear Queue
            </Button>
          </div>
        )}

        {/* Offline Operations Details */}
        {offlineQueue.count > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium">Pending Operations:</h4>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {offlineQueue.operations.map((op, index) => (
                <div key={op.id} className="flex items-center justify-between text-xs p-2 bg-muted rounded" data-testid={`operation-${index}`}>
                  <span className="font-mono">{op.type.toUpperCase()}</span>
                  <span className="truncate ml-2 flex-1">
                    {op.data.name || op.data.licenseNumber || op.id}
                  </span>
                  <Badge variant="outline" className="text-xs">
                    {op.retryCount > 0 ? `Retry ${op.retryCount}` : 'New'}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Conflict Alerts */}
        {conflicts.map((conflict, index) => (
          <Alert key={index} data-testid={`conflict-${index}`}>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="flex items-center justify-between">
              <div>
                Conflict detected during {conflict.operation.type} operation.
                Resolution: {conflict.resolution}
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => dismissConflict(index)}
                data-testid={`button-dismiss-conflict-${index}`}
              >
                Dismiss
              </Button>
            </AlertDescription>
          </Alert>
        ))}

        {/* Success indicator when queue is empty and no replay in progress */}
        {offlineQueue.count === 0 && !isReplaying && isOnline && dbType === 'network' && (
          <div className="flex items-center gap-2 text-sm text-green-600">
            <CheckCircle className="h-4 w-4" data-testid="icon-sync-complete" />
            All operations synchronized
          </div>
        )}
      </CardContent>
    </Card>
  );
}