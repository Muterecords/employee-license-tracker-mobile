import { useEffect } from "react";
import { useToast } from "../../hooks/use-toast";

export default function NetworkChangeNotifications() {
  const { toast } = useToast();

  useEffect(() => {
    const handleLicenseChangeNotification = (event: any) => {
      const { title, description, type } = event.detail;
      
      // Show toast notification with appropriate styling
      toast({
        title,
        description,
        variant: type === 'deleted' ? 'destructive' : 'default',
        duration: 5000, // Show for 5 seconds
      });
    };

    // Listen for license change notifications
    window.addEventListener('license-change-notification', handleLicenseChangeNotification);

    // Cleanup listener on unmount
    return () => {
      window.removeEventListener('license-change-notification', handleLicenseChangeNotification);
    };
  }, [toast]);

  // This component doesn't render anything visible - it just listens for events
  return null;
}