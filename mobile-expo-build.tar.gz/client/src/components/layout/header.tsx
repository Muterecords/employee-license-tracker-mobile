import { Bell, User } from "lucide-react";

interface HeaderProps {
  title: string;
  subtitle: string;
  notificationCount?: number;
}

export default function Header({ title, subtitle, notificationCount = 0 }: HeaderProps) {
  return (
    <header className="bg-card border-b border-border px-6 py-4 flex items-center justify-between" data-testid="header">
      <div>
        <h2 className="text-2xl font-semibold text-foreground">{title}</h2>
        <p className="text-sm text-muted-foreground">{subtitle}</p>
      </div>
      
      <div className="flex items-center gap-4">
        <button 
          className="relative p-2 text-muted-foreground hover:text-foreground transition-colors"
          data-testid="notifications-button"
        >
          <Bell size={20} />
          {notificationCount > 0 && (
            <span 
              className="absolute -top-1 -right-1 bg-destructive text-destructive-foreground text-xs rounded-full w-5 h-5 flex items-center justify-center"
              data-testid="notification-count"
            >
              {notificationCount}
            </span>
          )}
        </button>
        
        <div className="flex items-center gap-3">
          <div className="text-right">
            <p className="text-sm font-medium text-foreground">Admin User</p>
            <p className="text-xs text-muted-foreground">Administrator</p>
          </div>
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <User className="text-primary-foreground" size={16} />
          </div>
        </div>
      </div>
    </header>
  );
}
