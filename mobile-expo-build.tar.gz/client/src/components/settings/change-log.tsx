import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "../ui/dialog";
import { Button } from "../ui/button";
import { Badge } from "../ui/badge";
import { ScrollArea } from "../ui/scroll-area";
import { Separator } from "../ui/separator";
import { Download, Trash2, FileText } from "lucide-react";
import { changeLogger, LogEntry } from "../../lib/changeLogger";
import { useToast } from "../../hooks/use-toast";

interface ChangeLogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function ChangeLog({ open, onOpenChange }: ChangeLogProps) {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    if (open) {
      loadLogs();
    }
  }, [open]);

  const loadLogs = () => {
    const allLogs = changeLogger.getAllLogs();
    setLogs(allLogs);
  };

  const handleExportLogs = () => {
    try {
      const logText = changeLogger.exportLogs();
      const blob = new Blob([logText], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `license-changes-${new Date().toISOString().split('T')[0]}.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
      
      toast({
        title: "Export Successful",
        description: "Change log has been exported to file",
      });
    } catch (error) {
      toast({
        title: "Export Failed",
        description: "Failed to export change log",
        variant: "destructive"
      });
    }
  };

  const handleClearLogs = () => {
    if (confirm("Are you sure you want to clear all change logs? This action cannot be undone.")) {
      changeLogger.clearLogs();
      setLogs([]);
      toast({
        title: "Logs Cleared",
        description: "All change logs have been removed",
      });
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'NEW LICENCE ADDED':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'LICENCE UPDATED':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'LICENCE DELETED':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-200';
    }
  };

  const formatLogEntry = (log: LogEntry) => {
    return `[${log.date}:(${log.time})] ${log.action} - ${log.employeeName} : ${log.licenseType}`;
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText size={20} />
            Change Log
          </DialogTitle>
        </DialogHeader>

        <div className="flex justify-between items-center mb-4">
          <div className="text-sm text-muted-foreground">
            {logs.length} log entries
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleExportLogs}
              disabled={logs.length === 0}
              data-testid="export-logs-button"
            >
              <Download size={16} className="mr-2" />
              Export
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleClearLogs}
              disabled={logs.length === 0}
              data-testid="clear-logs-button"
            >
              <Trash2 size={16} className="mr-2" />
              Clear All
            </Button>
          </div>
        </div>

        <Separator />

        <ScrollArea className="h-[400px] w-full">
          {logs.length === 0 ? (
            <div className="flex items-center justify-center h-full text-muted-foreground">
              <div className="text-center">
                <FileText size={48} className="mx-auto mb-4 opacity-50" />
                <p>No change logs yet</p>
                <p className="text-sm">Changes will appear here when licenses are added, updated, or deleted</p>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 border rounded-lg bg-card"
                  data-testid={`log-entry-${log.id}`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="font-mono text-sm text-muted-foreground">
                      [{log.date}:({log.time})]
                    </div>
                    <Badge className={getActionColor(log.action)}>
                      {log.action}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <div className="font-medium">
                      {log.employeeName}
                    </div>
                    <div className="text-muted-foreground">:</div>
                    <div className="text-sm font-medium text-primary">
                      {log.licenseType}
                    </div>
                  </div>
                  
                  {log.details && (
                    <div className="text-sm text-muted-foreground mt-1">
                      {log.details}
                    </div>
                  )}

                  <div className="font-mono text-xs bg-muted p-2 rounded mt-2">
                    {formatLogEntry(log)}
                  </div>
                </div>
              ))}
            </div>
          )}
        </ScrollArea>
      </DialogContent>
    </Dialog>
  );
}