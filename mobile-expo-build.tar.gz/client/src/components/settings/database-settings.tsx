import { useState, useEffect } from "react";
import { Button } from "../ui/button";
import { Label } from "../ui/label";
import { Input } from "../ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../ui/card";
import { RadioGroup, RadioGroupItem } from "../ui/radio-group";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "../ui/dialog";
import { Settings, Database, Network, HardDrive, Users, RefreshCw, FileText, Info } from "lucide-react";
import { useToast } from "../../hooks/use-toast";
import ChangeLog from "./change-log";

interface DatabaseConfig {
  type: 'local' | 'network';
  networkPath: string;
  autoSync: boolean;
  syncInterval: number;
}

export default function DatabaseSettings() {
  const [config, setConfig] = useState<DatabaseConfig>({
    type: 'local',
    networkPath: '',
    autoSync: true,
    syncInterval: 5000
  });
  const [isOpen, setIsOpen] = useState(false);
  const [isTesting, setIsTesting] = useState(false);
  const [showChangeLog, setShowChangeLog] = useState(false);
  const { toast } = useToast();

  // Load config from localStorage
  useEffect(() => {
    const savedConfig = localStorage.getItem('license-tracker-db-config');
    if (savedConfig) {
      setConfig(JSON.parse(savedConfig));
    }
  }, []);

  const saveConfig = () => {
    // Validate network path if network type selected
    if (config.type === 'network' && !config.networkPath.trim()) {
      toast({
        title: "Error",
        description: "Please specify a network path for shared database",
        variant: "destructive"
      });
      return;
    }

    // Save to localStorage
    localStorage.setItem('license-tracker-db-config', JSON.stringify(config));
    
    // Notify storage layer to switch database type
    window.dispatchEvent(new CustomEvent('database-config-changed', { detail: config }));
    
    toast({
      title: "Settings Saved",
      description: `Database configured for ${config.type === 'local' ? 'local' : 'network'} storage`,
    });
    
    setIsOpen(false);
  };

  const testNetworkPath = async () => {
    if (!config.networkPath.trim()) {
      toast({
        title: "Error",
        description: "Please enter a network path first",
        variant: "destructive"
      });
      return;
    }

    setIsTesting(true);
    
    try {
      // Test if we can write to the network path
      const testData = { test: true, timestamp: Date.now() };
      const response = await fetch('/api/test-network-path', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ path: config.networkPath, data: testData })
      });

      if (response.ok) {
        toast({
          title: "Success",
          description: "Network path is accessible and writable",
        });
      } else {
        const error = await response.text();
        toast({
          title: "Error",
          description: `Network path test failed: ${error}`,
          variant: "destructive"
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to test network path",
        variant: "destructive"
      });
    } finally {
      setIsTesting(false);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          size="sm"
          data-testid="database-settings-button"
        >
          <Settings size={16} className="mr-2" />
          Database Settings
        </Button>
      </DialogTrigger>
      
      <DialogContent className="max-w-2xl" data-testid="database-settings-dialog">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Database size={20} />
            Database Configuration
          </DialogTitle>
          <DialogDescription>
            Configure where your license data is stored and how it's shared across multiple computers
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Database Type Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Storage Type</CardTitle>
              <CardDescription>
                Choose between local storage (single computer) or network storage (shared across multiple computers)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <RadioGroup
                value={config.type}
                onValueChange={(value: 'local' | 'network') => 
                  setConfig(prev => ({ ...prev, type: value }))
                }
                data-testid="storage-type-selection"
              >
                <div className="flex items-center space-x-2 p-3 border rounded-lg">
                  <RadioGroupItem value="local" id="local" />
                  <div className="flex-1">
                    <Label htmlFor="local" className="flex items-center gap-2 font-medium">
                      <HardDrive size={16} />
                      Local Storage
                    </Label>
                    <p className="text-sm text-muted-foreground mt-1">
                      Data stored on this computer only. Fast and simple, but not shared.
                    </p>
                  </div>
                </div>
                
                <div className="flex items-center space-x-2 p-3 border rounded-lg">
                  <RadioGroupItem value="network" id="network" />
                  <div className="flex-1">
                    <Label htmlFor="network" className="flex items-center gap-2 font-medium">
                      <Network size={16} />
                      Network Storage
                    </Label>
                    <p className="text-sm text-muted-foreground mt-1">
                      Data stored on network drive. Shared across multiple computers with live updates.
                    </p>
                  </div>
                </div>
              </RadioGroup>
            </CardContent>
          </Card>

          {/* Network Path Configuration */}
          {config.type === 'network' && (
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Users size={18} />
                  Network Configuration
                </CardTitle>
                <CardDescription>
                  Specify the network location where the shared database will be stored
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="networkPath">Network Path</Label>
                  <div className="flex gap-2 mt-1">
                    <Input
                      id="networkPath"
                      placeholder="\\server\shared\LicenseTracker or Z:\LicenseTracker"
                      value={config.networkPath}
                      onChange={(e) => 
                        setConfig(prev => ({ ...prev, networkPath: e.target.value }))
                      }
                      className="flex-1"
                      data-testid="network-path-input"
                    />
                    <Button
                      variant="outline"
                      onClick={testNetworkPath}
                      disabled={isTesting}
                      data-testid="test-network-path"
                    >
                      {isTesting ? (
                        <RefreshCw size={16} className="animate-spin" />
                      ) : (
                        "Test"
                      )}
                    </Button>
                  </div>
                  <p className="text-sm text-muted-foreground mt-2">
                    Examples: <code>\\ComputerName\SharedFolder</code> or <code>Z:\LicenseTracker</code>
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="syncInterval">Auto-Sync Interval (seconds)</Label>
                    <Input
                      id="syncInterval"
                      type="number"
                      min="1"
                      max="300"
                      value={config.syncInterval / 1000}
                      onChange={(e) => 
                        setConfig(prev => ({ 
                          ...prev, 
                          syncInterval: Math.max(1, parseInt(e.target.value) || 5) * 1000 
                        }))
                      }
                      data-testid="sync-interval-input"
                    />
                    <p className="text-sm text-muted-foreground mt-1">
                      How often to check for changes from other users
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Change Log Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <FileText size={18} />
                Change Log
              </CardTitle>
              <CardDescription>
                View a history of all license changes, additions, and deletions
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button
                variant="outline"
                onClick={() => setShowChangeLog(true)}
                data-testid="view-change-log"
              >
                <FileText size={16} className="mr-2" />
                View Change Log
              </Button>
            </CardContent>
          </Card>

          {/* About Section */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Info size={18} />
                About
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground leading-relaxed">
                This software is provided as a trial version for evaluation purposes only. It is not a fully licensed product and is intended for use solely within the designated trial workplace. Distribution, installation, or use across multiple sites or organizations requires a valid license agreement.
              </p>
            </CardContent>
          </Card>

          {/* Save/Cancel Buttons */}
          <div className="flex justify-end gap-2 pt-4 border-t">
            <Button
              variant="outline"
              onClick={() => setIsOpen(false)}
              data-testid="cancel-settings"
            >
              Cancel
            </Button>
            <Button
              onClick={saveConfig}
              data-testid="save-settings"
            >
              Save Settings
            </Button>
          </div>
        </div>
      </DialogContent>

      {/* Change Log Dialog */}
      <ChangeLog 
        open={showChangeLog} 
        onOpenChange={setShowChangeLog} 
      />
    </Dialog>
  );
}