import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { License } from "../../shared/schema";
import { formatDate } from "../../lib/date-utils";

interface DuplicateLicenseDialogProps {
  isOpen: boolean;
  onClose: () => void;
  onUpdate: () => void;
  onCreateNew: () => void;
  existingLicense: License;
  licenseNumber: string;
}

export default function DuplicateLicenseDialog({
  isOpen,
  onClose,
  onUpdate,
  onCreateNew,
  existingLicense,
  licenseNumber
}: DuplicateLicenseDialogProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent data-testid="duplicate-license-dialog">
        <DialogHeader>
          <DialogTitle>Duplicate License Number Found</DialogTitle>
          <DialogDescription>
            A license with number "{licenseNumber}" already exists in the system.
          </DialogDescription>
        </DialogHeader>
        
        <div className="bg-muted p-4 rounded-lg">
          <h4 className="font-medium text-foreground mb-2">Existing License:</h4>
          <div className="space-y-1 text-sm">
            <p><span className="font-medium">Employee:</span> {existingLicense.name}</p>
            <p><span className="font-medium">Type:</span> {existingLicense.type}</p>
            <p><span className="font-medium">License Number:</span> #{existingLicense.licenseNumber}</p>
            <p><span className="font-medium">Expiry Date:</span> {formatDate(existingLicense.expiryDate)}</p>
            {existingLicense.description && (
              <p><span className="font-medium">Notes:</span> {existingLicense.description}</p>
            )}
          </div>
        </div>

        <DialogFooter className="flex flex-col sm:flex-row gap-2">
          <Button
            variant="outline"
            onClick={onClose}
            data-testid="cancel-duplicate"
          >
            Cancel
          </Button>
          <Button
            variant="secondary"
            onClick={onUpdate}
            data-testid="update-existing"
          >
            Update Existing License
          </Button>
          <Button
            onClick={onCreateNew}
            data-testid="create-anyway"
          >
            Create New License Anyway
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}