import { useState, useRef } from "react";
import { Button } from "../ui/button";
import { Label } from "../ui/label";
import { Camera, Upload, X, Eye } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../ui/dialog";

interface PhotoUploadProps {
  label: string;
  photo: string | null;
  onPhotoChange: (photo: string | null) => void;
  placeholder?: string;
}

export default function PhotoUpload({ label, photo, onPhotoChange, placeholder }: PhotoUploadProps) {
  const [showPreview, setShowPreview] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      // Check file size (limit to 5MB)
      if (file.size > 5 * 1024 * 1024) {
        alert('File size must be less than 5MB');
        return;
      }

      // Check file type
      if (!file.type.startsWith('image/')) {
        alert('Please select an image file');
        return;
      }

      const reader = new FileReader();
      reader.onload = (e) => {
        const result = e.target?.result as string;
        onPhotoChange(result);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleRemovePhoto = () => {
    onPhotoChange(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleUploadClick = () => {
    fileInputRef.current?.click();
  };

  return (
    <div className="space-y-2">
      <Label>{label} {placeholder && <span className="text-muted-foreground text-sm">({placeholder})</span>}</Label>
      
      <div className="flex items-center gap-2">
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleFileSelect}
          className="hidden"
          data-testid={`photo-input-${label.toLowerCase().replace(' ', '-')}`}
        />
        
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={handleUploadClick}
          data-testid={`upload-${label.toLowerCase().replace(' ', '-')}`}
        >
          <Upload size={16} className="mr-2" />
          Upload {label}
        </Button>

        {photo && (
          <>
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => setShowPreview(true)}
              data-testid={`view-${label.toLowerCase().replace(' ', '-')}`}
            >
              <Eye size={16} className="mr-2" />
              View
            </Button>
            
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={handleRemovePhoto}
              className="text-destructive hover:text-destructive"
              data-testid={`remove-${label.toLowerCase().replace(' ', '-')}`}
            >
              <X size={16} className="mr-2" />
              Remove
            </Button>
          </>
        )}
      </div>

      {photo && (
        <div className="text-sm text-muted-foreground">
          ✓ {label} uploaded
        </div>
      )}

      {/* Photo Preview Modal */}
      <Dialog open={showPreview} onOpenChange={setShowPreview}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{label} Preview</DialogTitle>
            <DialogDescription>
              License {label.toLowerCase()} photo
            </DialogDescription>
          </DialogHeader>
          
          {photo && (
            <div className="flex justify-center">
              <img
                src={photo}
                alt={`${label} preview`}
                className="max-w-full max-h-96 object-contain rounded-lg border"
              />
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}