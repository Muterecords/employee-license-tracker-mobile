import { AlertCircle, Clock } from "lucide-react";
import { License } from "../../shared/schema";
import { getDaysUntilExpiry, getLicenseStatus } from "../../lib/date-utils";

interface AlertsSectionProps {
  licenses: License[];
}

export default function AlertsSection({ licenses }: AlertsSectionProps) {
  const urgentAlerts = licenses
    .map(license => ({
      ...license,
      daysLeft: getDaysUntilExpiry(license.expiryDate),
      status: getLicenseStatus(license.expiryDate)
    }))
    .filter(license => license.status === 'expired' || (license.status === 'expiring' && license.daysLeft <= 7))
    .sort((a, b) => a.daysLeft - b.daysLeft);

  if (urgentAlerts.length === 0) {
    return null;
  }

  return (
    <div className="mb-8" data-testid="alerts-section">
      <h3 className="text-lg font-semibold text-foreground mb-4">Urgent Alerts</h3>
      <div className="space-y-3">
        {urgentAlerts.map((license) => {
          const isExpired = license.status === 'expired';
          const alertClass = isExpired 
            ? "bg-red-50 border-red-200 dark:bg-red-950 dark:border-red-800"
            : "bg-amber-50 border-amber-200 dark:bg-amber-950 dark:border-amber-800";
          const iconClass = isExpired ? "text-red-600" : "text-amber-600";
          const titleClass = isExpired ? "text-red-700 dark:text-red-300" : "text-amber-700 dark:text-amber-300";
          const textClass = isExpired ? "text-red-600 dark:text-red-400" : "text-amber-600 dark:text-amber-400";
          
          return (
            <div 
              key={license.id}
              className={`${alertClass} border rounded-lg p-4 flex items-start gap-3`}
              data-testid={`alert-${license.id}`}
            >
              {isExpired ? (
                <AlertCircle className={`${iconClass} mt-0.5`} size={20} />
              ) : (
                <Clock className={`${iconClass} mt-0.5`} size={20} />
              )}
              <div>
                <p className={`font-medium ${titleClass}`}>
                  {isExpired ? 'License Expired' : 'License Expiring Soon'}
                </p>
                <p className={`text-sm ${textClass}`}>
                  {license.name} {isExpired 
                    ? `expired ${Math.abs(license.daysLeft)} days ago`
                    : `expires in ${license.daysLeft} days`
                  }. {isExpired ? 'Immediate renewal required.' : 'Schedule renewal now.'}
                </p>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
