import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Edit, Trash2, Search, ArrowUpDown, Plus, Camera, Eye } from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "../ui/alert-dialog";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "../ui/dialog";
import { License } from "../../shared/schema";
import { getDaysUntilExpiry, getLicenseStatus, formatDate, getStatusColor, getDaysLeftColor } from "../../lib/date-utils";
import { apiRequest } from "../../lib/queryClient";
import { useToast } from "../../hooks/use-toast";
import LicenseForm from "./license-form";
import DatabaseSettings from "../settings/database-settings";
import NetworkStatus from "../ui/network-status";

interface LicenseTableProps {
  licenses: License[];
}

export default function LicenseTable({ licenses }: LicenseTableProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [sortField, setSortField] = useState<"name" | "expiryDate">("expiryDate");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [editingLicense, setEditingLicense] = useState<License | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);
  const [viewPhotoLicense, setViewPhotoLicense] = useState<License | null>(null);
  const [viewPhotoType, setViewPhotoType] = useState<"front" | "back" | null>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/licenses/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/licenses"] });
      toast({ title: "Success", description: "Employee deleted successfully" });
      setDeleteId(null);
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const filteredAndSortedLicenses = licenses
    .filter(license => {
      const matchesSearch = license.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           license.type.toLowerCase().includes(searchTerm.toLowerCase());
      const status = getLicenseStatus(license.expiryDate);
      const matchesStatus = statusFilter === "all" || status === statusFilter;
      return matchesSearch && matchesStatus;
    })
    .sort((a, b) => {
      let aValue, bValue;
      
      if (sortField === "name") {
        aValue = a.name.toLowerCase();
        bValue = b.name.toLowerCase();
      } else {
        aValue = new Date(a.expiryDate).getTime();
        bValue = new Date(b.expiryDate).getTime();
      }
      
      if (sortDirection === "asc") {
        return aValue < bValue ? -1 : aValue > bValue ? 1 : 0;
      } else {
        return aValue > bValue ? -1 : aValue < bValue ? 1 : 0;
      }
    });

  const handleSort = (field: "name" | "expiryDate") => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  return (
    <>
      <div className="bg-card rounded-lg border border-border" data-testid="license-table">
        <div className="p-6 border-b border-border">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-3">
              <h3 className="text-lg font-semibold text-foreground">Employee License Overview</h3>
              <NetworkStatus />
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={16} />
                <Input
                  placeholder="Search employees..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                  data-testid="search-input"
                />
              </div>
              
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger data-testid="status-filter">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="expiring">Expiring Soon</SelectItem>
                  <SelectItem value="expired">Expired</SelectItem>
                </SelectContent>
              </Select>
              
              <DatabaseSettings />
              
              <Button 
                onClick={() => setShowAddForm(true)}
                data-testid="add-license-button"
              >
                <Plus size={16} className="mr-2" />
                Add License
              </Button>
            </div>
          </div>
        </div>
        
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-muted">
              <tr>
                <th className="text-left p-4 font-medium text-muted-foreground">
                  <button 
                    className="flex items-center gap-1 hover:text-foreground"
                    onClick={() => handleSort("name")}
                    data-testid="sort-name"
                  >
                    Employee Name
                    <ArrowUpDown size={12} />
                  </button>
                </th>
                <th className="text-left p-4 font-medium text-muted-foreground">Type</th>
                <th className="text-center p-4 font-medium text-muted-foreground">Photos</th>
                <th className="text-left p-4 font-medium text-muted-foreground">
                  <button 
                    className="flex items-center gap-1 hover:text-foreground"
                    onClick={() => handleSort("expiryDate")}
                    data-testid="sort-expiry"
                  >
                    Expiry Date
                    <ArrowUpDown size={12} />
                  </button>
                </th>
                <th className="text-left p-4 font-medium text-muted-foreground">Days Left</th>
                <th className="text-left p-4 font-medium text-muted-foreground">Status</th>
                <th className="text-left p-4 font-medium text-muted-foreground">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {filteredAndSortedLicenses.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-8 text-center text-muted-foreground" data-testid="empty-state">
                    No employees found. {searchTerm || statusFilter !== "all" ? "Try adjusting your filters." : "Add your first employee to get started."}
                  </td>
                </tr>
              ) : (
                filteredAndSortedLicenses.map((license) => {
                  const daysLeft = getDaysUntilExpiry(license.expiryDate);
                  const status = getLicenseStatus(license.expiryDate);
                  const statusColor = getStatusColor(status);
                  const daysLeftColor = getDaysLeftColor(daysLeft);
                  
                  return (
                    <tr 
                      key={license.id}
                      className="hover:bg-accent/50 transition-colors"
                      data-testid={`license-row-${license.id}`}
                    >
                      <td className="p-4">
                        <div className="font-medium text-foreground">{license.name}</div>
                        {license.licenseNumber && (
                          <div className="text-sm text-muted-foreground">#{license.licenseNumber}</div>
                        )}
                        {license.description && (
                          <div className="text-sm text-muted-foreground">{license.description}</div>
                        )}
                      </td>
                      <td className="p-4 text-sm text-muted-foreground capitalize">{license.type}</td>
                      <td className="p-4">
                        <div className="flex items-center justify-center gap-1">
                          {license.frontPhoto && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setViewPhotoLicense(license);
                                setViewPhotoType("front");
                              }}
                              className="p-1 h-6 w-6"
                              title="View front photo"
                              data-testid={`view-front-photo-${license.id}`}
                            >
                              <Camera size={12} className="text-blue-600" />
                            </Button>
                          )}
                          {license.backPhoto && (
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => {
                                setViewPhotoLicense(license);
                                setViewPhotoType("back");
                              }}
                              className="p-1 h-6 w-6"
                              title="View back photo"
                              data-testid={`view-back-photo-${license.id}`}
                            >
                              <Camera size={12} className="text-green-600" />
                            </Button>
                          )}
                          {!license.frontPhoto && !license.backPhoto && (
                            <span className="text-xs text-muted-foreground">—</span>
                          )}
                        </div>
                      </td>
                      <td className="p-4 text-sm text-muted-foreground">{formatDate(license.expiryDate)}</td>
                      <td className={`p-4 text-sm font-medium ${daysLeftColor}`}>
                        {daysLeft < 0 ? `${Math.abs(daysLeft)} days ago` : `${daysLeft} days`}
                      </td>
                      <td className="p-4">
                        <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${statusColor}`}>
                          {status === 'expiring' ? 'Expiring Soon' : status.charAt(0).toUpperCase() + status.slice(1)}
                        </span>
                      </td>
                      <td className="p-4">
                        <div className="flex items-center gap-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setEditingLicense(license)}
                            data-testid={`edit-license-${license.id}`}
                          >
                            <Edit size={16} />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => setDeleteId(license.id)}
                            className="text-destructive hover:text-destructive"
                            data-testid={`delete-license-${license.id}`}
                          >
                            <Trash2 size={16} />
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!deleteId} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent data-testid="delete-confirmation">
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This action cannot be undone. This will permanently delete the license.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId && deleteMutation.mutate(deleteId)}
              disabled={deleteMutation.isPending}
              data-testid="confirm-delete"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* License Forms */}
      {showAddForm && (
        <LicenseForm onClose={() => setShowAddForm(false)} />
      )}
      
      {editingLicense && (
        <LicenseForm 
          license={editingLicense} 
          onClose={() => setEditingLicense(null)} 
        />
      )}

      {/* Photo Viewer Dialog */}
      {viewPhotoLicense && viewPhotoType && (
        <Dialog open={true} onOpenChange={() => {
          setViewPhotoLicense(null);
          setViewPhotoType(null);
        }}>
          <DialogContent className="max-w-2xl" data-testid="photo-viewer">
            <DialogHeader>
              <DialogTitle>
                {viewPhotoType === "front" ? "Front" : "Back"} Photo - {viewPhotoLicense.name}
              </DialogTitle>
              <DialogDescription>
                {viewPhotoLicense.type} License {viewPhotoType} Photo
              </DialogDescription>
            </DialogHeader>
            
            <div className="flex justify-center">
              <img
                src={viewPhotoType === "front" ? viewPhotoLicense.frontPhoto! : viewPhotoLicense.backPhoto!}
                alt={`${viewPhotoType} photo of ${viewPhotoLicense.name}'s license`}
                className="max-w-full max-h-96 object-contain rounded-lg border"
              />
            </div>
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
