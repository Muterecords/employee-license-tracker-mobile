import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { X } from "lucide-react";
import { Button } from "../ui/button";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Textarea } from "../ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select";
import { insertLicenseSchema, type License, type InsertLicense } from "../../shared/schema";
import { apiRequest } from "../../lib/queryClient";
import { useToast } from "../../hooks/use-toast";
import DuplicateLicenseDialog from "./duplicate-license-dialog";
import PhotoUpload from "./photo-upload";

interface LicenseFormProps {
  license?: License;
  onClose: () => void;
}

export default function LicenseForm({ license, onClose }: LicenseFormProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const isEditing = !!license;
  const [selectedType, setSelectedType] = useState(license?.type || "");
  const [customType, setCustomType] = useState("");
  const [licenseNumber, setLicenseNumber] = useState(license?.licenseNumber || "");
  const [frontPhoto, setFrontPhoto] = useState<string | null>(license?.frontPhoto || null);
  const [backPhoto, setBackPhoto] = useState<string | null>(license?.backPhoto || null);
  const [showDuplicateDialog, setShowDuplicateDialog] = useState(false);
  const [duplicateLicense, setDuplicateLicense] = useState<License | null>(null);
  const [pendingSubmission, setPendingSubmission] = useState<InsertLicense | null>(null);

  const form = useForm<InsertLicense>({
    resolver: zodResolver(insertLicenseSchema),
    defaultValues: {
      name: license?.name || "",
      type: license?.type || "",
      licenseNumber: license?.licenseNumber || "",
      frontPhoto: license?.frontPhoto || "",
      backPhoto: license?.backPhoto || "",
      expiryDate: license?.expiryDate || "",
      description: license?.description || "",
    },
  });

  // Set initial custom type, license number, and photos if it's not one of the standard types
  useEffect(() => {
    if (license?.type && !["DGSC", "Shotfirer"].includes(license.type)) {
      setSelectedType("Other");
      setCustomType(license.type);
    } else {
      setSelectedType(license?.type || "");
    }
    setLicenseNumber(license?.licenseNumber || "");
    setFrontPhoto(license?.frontPhoto || null);
    setBackPhoto(license?.backPhoto || null);
  }, [license]);

  const createMutation = useMutation({
    mutationFn: (data: InsertLicense) => apiRequest("POST", "/api/licenses", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/licenses"] });
      toast({ title: "Success", description: "Employee added successfully" });
      onClose();
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data: InsertLicense) => 
      apiRequest("PUT", `/api/licenses/${license!.id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/licenses"] });
      toast({ title: "Success", description: "Employee updated successfully" });
      onClose();
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const checkForDuplicates = async (data: InsertLicense) => {
    // Only check if license number is provided
    if (!data.licenseNumber?.trim()) {
      return null;
    }

    try {
      const response = await apiRequest("POST", "/api/licenses/check-duplicate", {
        licenseNumber: data.licenseNumber,
        excludeId: isEditing ? license?.id : undefined
      });
      return response.exists ? response.license : null;
    } catch (error) {
      console.error("Error checking for duplicates:", error);
      return null;
    }
  };

  const onSubmit = async (data: InsertLicense) => {
    const submissionData = { ...data };
    
    // If "Other" is selected, use the custom type value
    if (selectedType === "Other") {
      submissionData.type = customType;
    }
    
    // Always include license number and photos
    submissionData.licenseNumber = licenseNumber;
    submissionData.frontPhoto = frontPhoto;
    submissionData.backPhoto = backPhoto;

    // Check for duplicates
    const duplicateFound = await checkForDuplicates(submissionData);
    if (duplicateFound) {
      setDuplicateLicense(duplicateFound);
      setPendingSubmission(submissionData);
      setShowDuplicateDialog(true);
      return;
    }
    
    // No duplicates found, proceed with submission
    if (isEditing) {
      updateMutation.mutate(submissionData);
    } else {
      createMutation.mutate(submissionData);
    }
  };

  const handleUpdateExisting = () => {
    if (duplicateLicense && pendingSubmission) {
      // Update the existing license with new data using PUT request
      const updateUrl = `/api/licenses/${duplicateLicense.id}`;
      apiRequest("PUT", updateUrl, pendingSubmission)
        .then(() => {
          queryClient.invalidateQueries({ queryKey: ['/api/licenses'] });
          toast({ title: "License updated successfully" });
          onClose();
        })
        .catch((error) => {
          toast({ title: "Error", description: error.message, variant: "destructive" });
        });
      setShowDuplicateDialog(false);
      setDuplicateLicense(null);
      setPendingSubmission(null);
    }
  };

  const handleCreateAnyway = () => {
    if (pendingSubmission) {
      // Create new license despite duplicate
      createMutation.mutate(pendingSubmission);
      setShowDuplicateDialog(false);
      setDuplicateLicense(null);
      setPendingSubmission(null);
    }
  };

  const handleCancelDuplicate = () => {
    setShowDuplicateDialog(false);
    setDuplicateLicense(null);
    setPendingSubmission(null);
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center p-4 z-50" data-testid="license-form-modal">
      <div className="bg-card rounded-lg border border-border w-full max-w-md">
        <div className="p-6 border-b border-border flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-foreground">
              {isEditing ? "Edit Employee" : "Add New Employee"}
            </h3>
            <p className="text-sm text-muted-foreground">
              {isEditing ? "Update the employee license details" : "Enter the details for the new employee"}
            </p>
          </div>
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            data-testid="close-form"
          >
            <X size={16} />
          </Button>
        </div>
        
        <form onSubmit={form.handleSubmit(onSubmit)} className="p-6 space-y-4">
          <div>
            <Label htmlFor="name">Employee Name</Label>
            <Input
              id="name"
              placeholder="e.g., John Smith"
              {...form.register("name")}
              data-testid="input-name"
            />
            {form.formState.errors.name && (
              <p className="text-sm text-destructive mt-1">{form.formState.errors.name.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="type">License Type</Label>
            <Select
              value={selectedType}
              onValueChange={(value) => {
                setSelectedType(value);
                if (value !== "Other") {
                  form.setValue("type", value);
                  setCustomType("");
                }
              }}
            >
              <SelectTrigger data-testid="select-type">
                <SelectValue placeholder="Select type..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="DGSC">DGSC</SelectItem>
                <SelectItem value="Shotfirer">Shotfirer</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
            {form.formState.errors.type && (
              <p className="text-sm text-destructive mt-1">{form.formState.errors.type.message}</p>
            )}
          </div>

          {selectedType === "Other" && (
            <div>
              <Label htmlFor="customType">Custom License Type</Label>
              <Input
                id="customType"
                placeholder="Enter custom license type"
                value={customType}
                onChange={(e) => {
                  setCustomType(e.target.value);
                  form.setValue("type", e.target.value);
                }}
                data-testid="input-custom-type"
              />
            </div>
          )}

          {(selectedType === "DGSC" || selectedType === "Shotfirer" || selectedType === "Other") && (
            <div>
              <Label htmlFor="licenseNumber">License Number</Label>
              <Input
                id="licenseNumber"
                placeholder="Enter license number"
                value={licenseNumber}
                onChange={(e) => {
                  setLicenseNumber(e.target.value);
                  form.setValue("licenseNumber", e.target.value);
                }}
                data-testid="input-license-number"
              />
            </div>
          )}

          {/* License Photos Section */}
          <div className="space-y-4 p-4 border rounded-lg bg-muted/20">
            <h4 className="font-medium text-sm text-foreground">License Photos (Optional)</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <PhotoUpload
                label="Front Photo"
                photo={frontPhoto}
                onPhotoChange={(photo) => {
                  setFrontPhoto(photo);
                  form.setValue("frontPhoto", photo || "");
                }}
                placeholder="Front side of license"
              />
              <PhotoUpload
                label="Back Photo"
                photo={backPhoto}
                onPhotoChange={(photo) => {
                  setBackPhoto(photo);
                  form.setValue("backPhoto", photo || "");
                }}
                placeholder="Back side of license"
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="expiryDate">Expiry Date</Label>
            <Input
              id="expiryDate"
              type="date"
              {...form.register("expiryDate")}
              data-testid="input-expiry-date"
            />
            {form.formState.errors.expiryDate && (
              <p className="text-sm text-destructive mt-1">{form.formState.errors.expiryDate.message}</p>
            )}
          </div>
          
          <div>
            <Label htmlFor="description">Notes (Optional)</Label>
            <Textarea
              id="description"
              rows={3}
              placeholder="Additional notes about this employee..."
              {...form.register("description")}
              data-testid="input-description"
            />
          </div>
          
          <div className="flex justify-end gap-3 pt-4">
            <Button 
              type="button" 
              variant="outline"
              onClick={onClose}
              disabled={isPending}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button 
              type="submit"
              disabled={isPending}
              data-testid="button-submit"
            >
              {isPending ? "Saving..." : isEditing ? "Update Employee" : "Add Employee"}
            </Button>
          </div>
        </form>
      </div>

      {/* Duplicate License Dialog */}
      {showDuplicateDialog && duplicateLicense && pendingSubmission && (
        <DuplicateLicenseDialog
          isOpen={showDuplicateDialog}
          onClose={handleCancelDuplicate}
          onUpdate={handleUpdateExisting}
          onCreateNew={handleCreateAnyway}
          existingLicense={duplicateLicense}
          licenseNumber={pendingSubmission.licenseNumber || ""}
        />
      )}
    </div>
  );
}
