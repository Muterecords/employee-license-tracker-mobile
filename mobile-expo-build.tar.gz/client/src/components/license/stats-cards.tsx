import { Tag, CheckCircle, AlertTriangle, XCircle } from "lucide-react";
import { License } from "../../shared/schema";
import { getLicenseStatus } from "../../lib/date-utils";

interface StatsCardsProps {
  licenses: License[];
}

export default function StatsCards({ licenses }: StatsCardsProps) {
  const stats = licenses.reduce(
    (acc, license) => {
      const status = getLicenseStatus(license.expiryDate);
      acc.total++;
      if (status === 'active') acc.active++;
      else if (status === 'expiring') acc.expiring++;
      else acc.expired++;
      return acc;
    },
    { total: 0, active: 0, expiring: 0, expired: 0 }
  );

  const cardData = [
    {
      title: "Total Licenses",
      value: stats.total,
      icon: Tag,
      bgColor: "bg-primary/10",
      iconColor: "text-primary",
      valueColor: "text-foreground",
      testId: "stats-total"
    },
    {
      title: "Active",
      value: stats.active,
      icon: CheckCircle,
      bgColor: "bg-green-100",
      iconColor: "text-green-600",
      valueColor: "text-green-600",
      testId: "stats-active"
    },
    {
      title: "Expiring Soon",
      value: stats.expiring,
      icon: AlertTriangle,
      bgColor: "bg-amber-100",
      iconColor: "text-amber-500",
      valueColor: "text-amber-500",
      testId: "stats-expiring"
    },
    {
      title: "Expired",
      value: stats.expired,
      icon: XCircle,
      bgColor: "bg-red-100",
      iconColor: "text-red-600",
      valueColor: "text-red-600",
      testId: "stats-expired"
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {cardData.map((card) => {
        const Icon = card.icon;
        return (
          <div 
            key={card.title}
            className="bg-card rounded-lg border border-border p-6"
            data-testid={card.testId}
          >
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                <p className={`text-3xl font-bold ${card.valueColor}`}>{card.value}</p>
              </div>
              <div className={`w-12 h-12 ${card.bgColor} rounded-lg flex items-center justify-center`}>
                <Icon className={card.iconColor} size={24} />
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
