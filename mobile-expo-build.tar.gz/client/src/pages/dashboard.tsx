import { useQuery } from "@tanstack/react-query";
import { License } from "../shared/schema";
import Header from "../components/layout/header";
import StatsCards from "../components/license/stats-cards";
import AlertsSection from "../components/license/alerts-section";
import LicenseTable from "../components/license/license-table";
import { Skeleton } from "../components/ui/skeleton";

export default function Dashboard() {
  const { data: licenses = [], isLoading } = useQuery<License[]>({
    queryKey: ["/api/licenses"],
  });

  const urgentAlerts = licenses.filter(license => {
    const today = new Date();
    const expiry = new Date(license.expiryDate);
    const daysLeft = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
    return daysLeft <= 7;
  });

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="Employee License Dashboard" 
          subtitle="Monitor your employee license renewals and compliance"
          notificationCount={0}
        />
        <main className="flex-1 overflow-auto p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {[...Array(4)].map((_, i) => (
              <Skeleton key={i} className="h-24" />
            ))}
          </div>
          <Skeleton className="h-64" />
        </main>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden" data-testid="dashboard">
      <Header 
        title="Employee License Dashboard" 
        subtitle="Monitor your employee license renewals and compliance"
        notificationCount={urgentAlerts.length}
      />
      
      <main className="flex-1 overflow-auto p-6">
        <StatsCards licenses={licenses} />
        <AlertsSection licenses={licenses} />
        <LicenseTable licenses={licenses} />
      </main>
    </div>
  );
}
