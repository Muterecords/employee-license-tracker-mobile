import { useQuery } from "@tanstack/react-query";
import { License } from "../shared/schema";
import Header from "../components/layout/header";
import LicenseTable from "../components/license/license-table";
import { Skeleton } from "../components/ui/skeleton";

export default function Licenses() {
  const { data: licenses = [], isLoading } = useQuery<License[]>({
    queryKey: ["/api/licenses"],
  });

  if (isLoading) {
    return (
      <div className="flex-1 flex flex-col overflow-hidden">
        <Header 
          title="All Licenses" 
          subtitle="Manage your license inventory"
        />
        <main className="flex-1 overflow-auto p-6">
          <Skeleton className="h-96" />
        </main>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col overflow-hidden" data-testid="licenses-page">
      <Header 
        title="All Licenses" 
        subtitle="Manage your license inventory"
      />
      
      <main className="flex-1 overflow-auto p-6">
        <LicenseTable licenses={licenses} />
      </main>
    </div>
  );
}
